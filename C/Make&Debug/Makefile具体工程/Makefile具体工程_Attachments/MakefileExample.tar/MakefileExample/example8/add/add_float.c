/*************************************************************************
    > File Name: add_float.c
    > Author: shift
    > Mail: open_shift@163.com 
    > Created Time: 2015年03月03日 星期二 20时25分30秒
 ************************************************************************/

float add_float(float a, float b)
{
	return a+b;
}
