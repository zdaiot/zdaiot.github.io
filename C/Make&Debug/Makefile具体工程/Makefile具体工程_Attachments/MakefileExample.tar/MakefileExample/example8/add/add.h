/*************************************************************************
    > File Name: add.h
    > Author: shift
    > Mail: open_shift@163.com 
    > Created Time: 2015年03月03日 星期二 20时22分58秒
 ************************************************************************/

#ifndef __ADD_H__
#define __ADD_H__

extern int add_int(int a, int b);
extern float add_float(float a, float b);

#endif
