/*************************************************************************
    > File Name: sub_float.c
    > Author: shift
    > Mail: open_shift@163.com 
    > Created Time: 2015年03月03日 星期二 20时29分49秒
 ************************************************************************/

float sub_float(float a, float b)
{
	return a-b;
}
