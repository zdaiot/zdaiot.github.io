#########################################################################
# File Name: clean.sh
# Author: shift
# mail: open_shift@163.com
# Created Time: 2015年03月03日 星期二 21时30分34秒
#########################################################################
#!/bin/bash

#delete cacu
rm -f cacu

#delelte *.o
rm -rf add/*.o sub/*.o *.o

#delete tags
rm -f tags
