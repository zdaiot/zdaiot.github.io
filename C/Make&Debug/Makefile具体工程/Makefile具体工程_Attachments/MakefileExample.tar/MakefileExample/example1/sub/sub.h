/*************************************************************************
    > File Name: sub.h
    > Author: shift
    > Mail: open_shift@163.com 
    > Created Time: 2015年03月03日 星期二 20时27分47秒
 ************************************************************************/

#ifndef __ADD_H__
#define __ADD_H__

extern float sub_float(float x, float y);
extern int sub_int(int a, int b);

#endif
